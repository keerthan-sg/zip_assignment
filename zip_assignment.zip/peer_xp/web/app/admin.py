from django.contrib import admin
from .models import login_table
# Register your models here.
admin.site.register(login_table)